package com.syam.desitv.data

object Config {
    /** Source: https://iptv-org.github.io/iptv/index.m3u (fetched via its per-language playlists). */
    const val PLAYLIST_BASE = "https://iptv-org.github.io/iptv"

    /**
     * English has 2,000+ channels worldwide. Set to true to keep only Indian English
     * channels (tvg-id ending in ".in"), e.g. NDTV 24x7, Times Now, India Today.
     */
    const val ENGLISH_INDIA_ONLY = false

    /**
     * Radio station list, read from the GitHub repo on every sync. Edit radio.m3u on GitHub
     * and press "Sync now" (or wait for the daily sync); no reinstall needed.
     */
    const val RADIO_PLAYLIST_URLS = "https://raw.githubusercontent.com/lalkrishnank/DesiTV/main/radio.m3u|" +
        "https://cdn.jsdelivr.net/gh/lalkrishnank/DesiTV@main/radio.m3u"

    /** Kids songs list (YouTube links), read from the GitHub repo on every sync. */
    const val YOUTUBE_LIST_URLS = "https://raw.githubusercontent.com/lalkrishnank/DesiTV/main/youtube.txt|" +
        "https://cdn.jsdelivr.net/gh/lalkrishnank/DesiTV@main/youtube.txt"

    /** Bump when a new kind of channel is added, so the app re-syncs after an update. */
    const val DATA_VERSION = 3

    /** While radio plays, start the TV's ambient mode / screensaver after this much idle time. */
    const val RADIO_AMBIENT_DELAY_MS = 30_000L

    /** Hours between automatic playlist syncs. */
    const val SYNC_INTERVAL_HOURS = 24L

    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 11; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    fun accept(channel: Channel): Boolean {
        if (channel.url.isBlank()) return false
        if (channel.language == Language.ENGLISH && ENGLISH_INDIA_ONLY) {
            return channel.tvgId.substringBefore('@').lowercase().endsWith(".in")
        }
        return true
    }
}
