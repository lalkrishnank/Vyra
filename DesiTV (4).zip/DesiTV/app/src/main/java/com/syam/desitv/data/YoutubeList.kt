package com.syam.desitv.data

/**
 * Reads youtube.txt: one song or playlist per line, optionally "Name | link".
 * Lines starting with # are notes and are ignored.
 */
object YoutubeList {
    private val videoRegex = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})""")
    private val listRegex = Regex("""[?&]list=([A-Za-z0-9_-]+)""")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val name: String
            val link: String
            if ('|' in line) {
                name = line.substringBefore('|').trim()
                link = line.substringAfter('|').trim()
            } else {
                name = ""
                link = line
            }
            val video = videoRegex.find(link)?.groupValues?.get(1)
            val list = listRegex.find(link)?.groupValues?.get(1)
            if (video == null && list == null) continue
            val isPlaylist = list != null && video == null
            out += Channel(
                name = name.ifEmpty { if (isPlaylist) "Playlist ${out.size + 1}" else "Song ${out.size + 1}" },
                url = "yt:${video ?: "-"}:${list ?: "-"}",
                logo = if (video != null) "https://img.youtube.com/vi/$video/hqdefault.jpg" else "",
                tvgId = "",
                group = if (list != null) "YouTube playlist" else "YouTube",
                language = Language.KIDS,
            )
        }
        return out
    }

    /** Returns (videoId, playlistId) from a channel url made by [parse]. */
    fun ids(url: String): Pair<String?, String?> {
        val parts = url.split(':')
        val video = parts.getOrNull(1)?.takeIf { it != "-" }
        val list = parts.getOrNull(2)?.takeIf { it != "-" }
        return video to list
    }
}
