package com.syam.desitv.player

/** Small web page that runs YouTube's official embedded player full screen. */
object YoutubePage {
    const val BASE_URL = "https://lalkrishnank.github.io/Vyra/"
    private const val ORIGIN = "https://lalkrishnank.github.io"

    fun html(videoId: String?, listId: String?): String {
        val videoPart = if (videoId != null) "videoId: '$videoId'," else ""
        val listPart = if (listId != null) "listType: 'playlist', list: '$listId'," else ""
        return """<!DOCTYPE html>
<html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}
#p{position:absolute;top:0;left:0;width:100%;height:100%}</style></head>
<body><div id="p"></div>
<script>
var player;
function onYouTubeIframeAPIReady() {
  player = new YT.Player('p', {
    width: '100%', height: '100%', $videoPart
    playerVars: { $listPart autoplay: 1, controls: 1, rel: 0, playsinline: 1, fs: 0,
                  iv_load_policy: 3, origin: '$ORIGIN' },
    events: {
      onReady: function (e) { e.target.playVideo(); },
      onStateChange: function (e) {
        if (e.data === 0) {
          var pl = player.getPlaylist ? player.getPlaylist() : null;
          var i = player.getPlaylistIndex ? player.getPlaylistIndex() : -1;
          if (!pl || i >= pl.length - 1) Android.onEnded();
        }
      },
      onError: function (e) { Android.onError(e.data); }
    }
  });
}
function togglePlay() {
  if (!player) return;
  if (player.getPlayerState() === 1) player.pauseVideo(); else player.playVideo();
}
</script>
<script src="https://www.youtube.com/iframe_api"></script>
</body></html>"""
    }
}
