# Vyra — Your World. Your Wave.

Android TV app: Malayalam, Tamil, Hindi and English live TV (iptv-org), Malayalam radio,
and a Kids tab with YouTube songs. Channels also appear in Google's Live Channels app.

* `radio.m3u` (repo root): radio stations. Edit and press **Sync now** on the TV.
* `youtube.txt` (repo root): Kids songs, one per line as `Name | YouTube link`.
* Latest APK: https://github.com/lalkrishnank/Vyra/releases/latest/download/Vyra.apk

To update the app: upload the new project zip and wait for the green tick under **Actions**.
